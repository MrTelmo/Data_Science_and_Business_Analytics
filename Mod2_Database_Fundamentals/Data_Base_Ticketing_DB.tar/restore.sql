--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Bilheteira";
--
-- Name: Bilheteira; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Bilheteira" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE "Bilheteira" OWNER TO postgres;

\unrestrict (null)
\connect "Bilheteira"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artista; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artista (
    nif integer NOT NULL,
    nome character varying(250),
    d_nasc date,
    tipo character varying(50)
);


ALTER TABLE public.artista OWNER TO postgres;

--
-- Name: bilhete; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bilhete (
    id integer NOT NULL,
    lugar integer,
    email character varying(150) NOT NULL,
    custo money
);


ALTER TABLE public.bilhete OWNER TO postgres;

--
-- Name: espectador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.espectador (
    email character varying(150) NOT NULL,
    nome character varying(250),
    cidade character varying(150)
);


ALTER TABLE public.espectador OWNER TO postgres;

--
-- Name: espetaculo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.espetaculo (
    id integer NOT NULL,
    titulo character varying(100),
    dia date,
    hora integer,
    preco money,
    categoria character varying(100),
    nif integer
);


ALTER TABLE public.espetaculo OWNER TO postgres;

--
-- Data for Name: artista; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artista (nif, nome, d_nasc, tipo) FROM stdin;
\.
COPY public.artista (nif, nome, d_nasc, tipo) FROM '$$PATH$$/5020.dat';

--
-- Data for Name: bilhete; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bilhete (id, lugar, email, custo) FROM stdin;
\.
COPY public.bilhete (id, lugar, email, custo) FROM '$$PATH$$/5023.dat';

--
-- Data for Name: espectador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.espectador (email, nome, cidade) FROM stdin;
\.
COPY public.espectador (email, nome, cidade) FROM '$$PATH$$/5022.dat';

--
-- Data for Name: espetaculo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.espetaculo (id, titulo, dia, hora, preco, categoria, nif) FROM stdin;
\.
COPY public.espetaculo (id, titulo, dia, hora, preco, categoria, nif) FROM '$$PATH$$/5021.dat';

--
-- Name: artista artista_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artista
    ADD CONSTRAINT artista_pkey PRIMARY KEY (nif);


--
-- Name: espectador espectador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.espectador
    ADD CONSTRAINT espectador_pkey PRIMARY KEY (email);


--
-- Name: espetaculo espetaculo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.espetaculo
    ADD CONSTRAINT espetaculo_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

